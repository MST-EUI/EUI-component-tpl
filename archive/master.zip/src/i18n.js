module.exports = {
  'zh-cn': {
    description: '暂无数据',
  },
  en: {
    description: 'Data is empty.',
  },
};

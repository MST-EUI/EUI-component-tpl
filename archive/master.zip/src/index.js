import EmptyData from './EmptyData';

module.exports = EmptyData;

